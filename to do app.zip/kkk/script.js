document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('new-task');
    const addTaskButton = document.getElementById('add-task');
    const taskList = document.getElementById('task-list');
    const undoContainer = document.getElementById('undo-container');
    const undoButton = document.getElementById('undo-button');
    
    let lastRemovedTask = null;
    let removalTimeout = null;
    let undoTimeout = null;

    // Load tasks from localStorage
    loadTasks();

    addTaskButton.addEventListener('click', addTask);
    taskInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            addTask();
        }
    });
    taskList.addEventListener('change', handleTaskCompletion);
    undoButton.addEventListener('click', undoRemoval);

    function addTask() {
        const taskText = taskInput.value.trim();
        if (taskText === '') return;

        const li = createTaskElement(taskText);
        taskList.appendChild(li);

        saveTasks();
        taskInput.value = '';
    }

    function handleTaskCompletion(e) {
        if (e.target.type === 'checkbox') {
            const taskItem = e.target.parentElement;
            taskItem.classList.add('completed');
            
            lastRemovedTask = {
                element: taskItem,
                text: taskItem.querySelector('span').textContent
            };

            removalTimeout = setTimeout(() => {
                taskItem.remove();
                saveTasks();
                showUndoContainer();
            }, 1000);

            hideUndoContainer(); 
        }
    }

    function undoRemoval() {
        clearTimeout(removalTimeout);
        clearTimeout(undoTimeout);
        taskList.appendChild(lastRemovedTask.element);
        lastRemovedTask.element.querySelector('input').checked = false;
        lastRemovedTask.element.classList.remove('completed');
        hideUndoContainer();
        saveTasks();
    }

    function createTaskElement(taskText) {
        const li = document.createElement('li');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';

        const span = document.createElement('span');
        span.textContent = taskText;

        li.appendChild(checkbox);
        li.appendChild(span);

        return li;
    }

    function saveTasks() {
        const tasks = [];
        taskList.querySelectorAll('li').forEach(task => {
            tasks.push({
                text: task.querySelector('span').textContent,
                completed: task.querySelector('input').checked
            });
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function loadTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks'));
        if (tasks) {
            tasks.forEach(task => {
                const li = createTaskElement(task.text);
                if (task.completed) {
                    li.classList.add('completed');
                    li.querySelector('input').checked = true;
                }
                taskList.appendChild(li);
            });
        }
    }

    function showUndoContainer() {
        undoContainer.style.display = 'block';
        setTimeout(() => {
            undoContainer.classList.add('show');
        }, 10); // Small delay to ensure the transition works
        
        // Auto-hide after 3 seconds
        undoTimeout = setTimeout(hideUndoContainer, 3000);
    }
    
    function hideUndoContainer() {
        undoContainer.classList.remove('show');
        setTimeout(() => {
            undoContainer.style.display = 'none';
        }, 500); // Match the transition duration
    }
});
